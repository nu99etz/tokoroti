<?php

class Auth extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model("Auth_M");
	}

	public function loginaksi(){
		$post = $this->input->post();
		$user = $post['username'];
		$pass = $post['password'];
		$data = $this->Auth_M->authProcess($user);
		if($data){
			if($pass==$data->password){
				$session = array(
					'logged'=>TRUE,
					'status'=>'sukses',
					'user'=>$data->nama_pegawai,
					'jabatan'=>$data->nama_jabatan,
					'pass'=>$data->password,
					'pesan'=>"Selamat Datang ".$data->nama_pegawai);
				$this->session->set_userdata($session);
				echo json_encode($session);
			} else {
				$session = array(
					'status'=>'gagal',
					'pesan'=>"Login Gagal");
				echo json_encode($session);
			}
		} else{
			$session = array(
				'status'=>'gagal',
				'pesan'=>"Login Gagal");
			echo json_encode($session);
		}
	}

	public function logout(){
		if($this->session->userdata('logged')){
			$this->session->sess_destroy();
			redirect("Utama/login");
		}
	} 
}