<?php

class Utama extends CI_Controller{
	
	public function __construct(){
		parent::__construct();
		$models = array(
			'Roti_M'=>'Roti_M',
			'Pegawai_M'=>'Pegawai_M');
		foreach($models as $model => $nama){
			$this->load->model($model,$nama);	
		}	
	}

	public function index(){
		if($this->session->userdata('logged')){
			$data['judul'] = "Toko Roti Barokah";
			$this->load->view('admin/_header',$data);
			$this->load->view('admin/_side_nav');
			$this->load->view('admin/dashboard');
			$this->load->view('admin/_footer');
		} else {
			redirect('Utama/login');
		}
	}

	public function login(){
		if($this->session->userdata('logged')){
			redirect('Utama/');
		} else {
			$data['judul'] = "Toko Roti Barokah";
			$this->load->view('admin/_header_laravel',$data);
			$this->load->view('admin/login_dash');
			$this->load->view('admin/_footer_login');
		}
	}

	public function viewroti(){
		if($this->session->userdata('logged')){
			$data['roti'] = $this->Roti_M->tampilroti();
			$data['kat'] = $this->Roti_M->listkategori();
			$data['judul'] = "Toko Roti Barokah - Roti";
			$this->load->view('admin/_header',$data);
			$this->load->view('admin/_side_nav');
			$this->load->view('admin/modal_roti',$data);
			$this->load->view('admin/_footer_roti');
		} else {
			redirect('Utama/login');
		}
	}

	public function tambahroti(){
		if($this->Roti_M->validasi("tambah")){
			$this->Roti_M->tambahaksi();
			$data['roti'] = $this->Roti_M->tampilroti();
			$html = $this->load->view('admin/viewroti',$data,true);
			$callback = array(
				'status'=>'sukses',
				'pesan'=>'Data Berhasil Disimpan',
				'html'=>$html);
		}else{
			$callback = array(
				'status'=>'gagal',
				'pesan'=>'Data Gagal Disimpan',
				'html'=>validation_errors());
		}
		echo json_encode($callback);
	}

	public function ubahroti(){
		if($this->Roti_M->validasi("ubah")){
			$this->Roti_M->editaksi();
			$data['roti'] = $this->Roti_M->tampilroti();
			$html = $this->load->view('admin/viewroti',$data,true);
			$callback = array(
				'status'=>'sukses',
				'pesan'=>'Data Berhasil Diubah',
				'html'=>$html);
		}else{
			$callback = array(
				'status'=>'gagal',
				'pesan'=>'Data Gagal Diubah',
				'html'=>validation_errors());
		}
		echo json_encode($callback);
	}

	public function hapusroti($id){
		$this->Roti_M->hapusaksi($id);
		$data['roti'] = $this->Roti_M->tampilroti();
		$html = $this->load->view('admin/viewroti',$data,true);
		$callback = array(
			'status'=>'sukses',
			'pesan'=>'Data Berhasil Dihapus',
			'html'=>$html);
		echo json_encode($callback);
	}

	public function cariroti(){
		$this->Roti_M->cariaksi();
		$data['roti'] = $this->Roti_M->cariaksi();
		$html = $this->load->view('admin/viewroti',$data,true);
		$callback = array(
			'pesan'=>"Ketemu ...",
			'html'=>$html);
		echo json_encode($callback);
	}

	public function caripegawai(){
		$this->Pegawai_M->cariaksi();
		$data['pegawai'] = $this->Pegawai_M->cariaksi();
		$html = $this->load->view('admin/viewpegawai',$data,true);
		$callback = array(
			'pesan'=>"Ketemu ...",
			'html'=>$html);
		echo json_encode($callback);
	}

	public function viewpegawai(){
		if($this->session->userdata('logged')){
			$data['pegawai'] = $this->Pegawai_M->tampilpegawai();
			$data['jabatan'] = $this->Pegawai_M->tampiljabatan();
			$data['judul'] = "Toko Roti Barokah - Pegawai";
			$this->load->view('admin/_header',$data);
			$this->load->view('admin/_side_nav');
			$this->load->view('admin/modal_pegawai',$data);
			$this->load->view('admin/_footer_pegawai');
		} else {
			redirect("Utama/login");
		}
	}

	public function tambahpegawai(){
		if($this->Pegawai_M->validasi("tambah")){
			$this->Pegawai_M->tambahaksi();
			$data['pegawai'] = $this->Pegawai_M->tampilpegawai();
			$html = $this->load->view('admin/viewpegawai',$data,true);
			$callback = array(
				'status'=>'sukses',
				'pesan'=>'Data Berhasil Disimpan',
				'html'=>$html);
		}else{
			$callback = array(
				'status'=>'gagal',
				'pesan'=>'Data Gagal Disimpan',
				'html'=>validation_errors());
		}
		echo json_encode($callback);
	}

	public function hapuspegawai($id){
		$this->Pegawai_M->hapusaksi($id);
		$data['pegawai'] = $this->Pegawai_M->tampilpegawai();
		$html = $this->load->view('admin/viewpegawai',$data,true);
		$callback = array(
			'status'=>'sukses',
			'pesan'=>'Data Berhasil Dihapus',
			'html'=>$html);
		echo json_encode($callback);
	}

	public function ubahpegawai(){
		if($this->Pegawai_M->validasi("ubah")){
			$this->Pegawai_M->editaksi();
			$data['pegawai'] = $this->Pegawai_M->tampilpegawai();
			$html = $this->load->view('admin/viewpegawai',$data,true);
			$callback = array(
				'status'=>'sukses',
				'pesan'=>'Data Berhasil Diubah',
				'html'=>$html);
		}else{
			$callback = array(
				'status'=>'gagal',
				'pesan'=>'Data Gagal Diubah',
				'html'=>validation_errors());
		}
		echo json_encode($callback);
	}
}