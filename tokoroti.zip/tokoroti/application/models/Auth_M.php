<?php

class Auth_M extends CI_Model{

	public function authProcess($user){
		$process = $this->db->query("SELECT*FROM pegawai p INNER JOIN jabatan j ON p.jabatan=j.id_jabatan WHERE nip = '$user'")->row();
		return $process;
	}
}