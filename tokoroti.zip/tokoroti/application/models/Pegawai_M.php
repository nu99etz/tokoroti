<?php

class Pegawai_M extends CI_Model{

	private function uploadGambar(){
    $config['upload_path']          = './assets/img/pegawai/';
    $config['allowed_types']        = 'gif|jpg|png|jpeg';
    $config['file_name']            = $this->nip;
    $config['overwrite']			= true;
    $config['max_size']             = 5000;
    $this->load->library('upload', $config);
    	if ($this->upload->do_upload('foto')) {
        	return $this->upload->data("file_name");
    	}
    		return "default.jpg";
	}

	private function hapusGambar($id){
   	 	$pegawai =  $this->db->get_where('pegawai',['nip'=>$id])->row();
	   	 	if ($pegawai->foto != "default.jpg") {
		    $filename = explode(".", $pegawai->foto)[0];
			return array_map('unlink', glob(FCPATH."assets/img/pegawai/$filename.*"));
    	}
	}

	public function validasi($data){
		$this->load->library('form_validation');
		if($data=="tambah"){
			$this->form_validation->set_rules('nip','NIP','required|numeric');
		}
		$this->form_validation->set_rules('nama_pegawai','Nama Pegawai','required');
		$this->form_validation->set_rules('jk','Jenis Kelamin','required');
		$this->form_validation->set_rules('jabatan','Jabatan','required');
		$this->form_validation->set_rules('password','Password','required');
		if($this->form_validation->run()){
			return true;
		}
		else{
			return false;
		}
	}

	public function tampilpegawai(){
		$lihat = $this->db->query("SELECT*FROM pegawai p INNER JOIN jabatan j ON p.jabatan=j.id_jabatan")->result_array();
		return $lihat;
	}

	public function tampiljabatan(){
		$lihat = $this->db->get('jabatan')->result_array();
		return $lihat;
	}

	public function tambahaksi(){
		$post = $this->input->post();
		$this->nama_pegawai = $post['nama_pegawai'];
		$this->jk = $post['jk'];
		$this->jabatan = $post['jabatan'];
		$this->password = $post['password'];
		$this->nip = $this->jabatan."-".$post['nip'];
		$this->foto = $this->uploadGambar();
		$this->db->insert('pegawai',$this);
	}

	public function hapusaksi($id){
		$this->hapusGambar($id);
		$this->db->delete('pegawai',array('nip'=>$id));
	}

	public function editaksi(){
		$post = $this->input->post();
		$this->nama_pegawai = $post['nama_pegawai'];
		$this->jk = $post['jk'];
		$this->jabatan = $post['jabatan'];
		$this->password = $post['password'];
		$this->nip = $post['nip'];
		if(empty($_FILES['foto']['name'])){
			$this->foto = $post['foto-lama'];
		}
		else{
			$this->hapusGambar($id);
			$this->foto = $this->uploadGambar();
		}		
		$this->db->update('pegawai',$this,array('nip'=>$post['nip']));
	}

	public function cariaksi(){
		$post = $this->input->post();
		$cari = $post['cari'];
		$this->db->select('*');
		$this->db->from('pegawai');
		$this->db->join('jabatan','pegawai.jabatan=jabatan.id_jabatan');
		$this->db->like('nama_pegawai',$cari);
		$ketemu = $this->db->get()->result_array();
		return $ketemu;
	}
}