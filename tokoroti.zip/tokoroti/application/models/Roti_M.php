<?php

class Roti_M extends CI_Model{

	private function uploadGambar(){
    $config['upload_path']          = './assets/img/roti/';
    $config['allowed_types']        = 'gif|jpg|png|jpeg';
    $config['file_name']            = $this->id_roti;
    $config['overwrite']			= true;
    $config['max_size']             = 5000;
    $this->load->library('upload', $config);
    	if ($this->upload->do_upload('foto')) {
        	return $this->upload->data("file_name");
    	}
    		return "default.jpg";
	}

	public function validasi($data){
		$this->load->library('form_validation');
		if($data=="tambah"){
			$this->form_validation->set_rules('id_roti','ID Roti','required|numeric');
		}
		$this->form_validation->set_rules('nama_roti','Nama Roti','required');
		$this->form_validation->set_rules('kategori','Kategori','required');
		$this->form_validation->set_rules('harga','Harga','required|numeric');
		$this->form_validation->set_rules('stok','Stok','required|numeric');
		if($this->form_validation->run()){
			return true;
		}
		else{
			return false;
		}
	}

	public function tampilroti(){
		$lihat = $this->db->query("SELECT*FROM roti r INNER JOIN kategori k ON r.id_kategori = k.id_kategori")->result_array();
		return $lihat;
	}

	public function listkategori(){
		$lihat = $this->db->get('kategori')->result_array();
		return $lihat;
	}

	public function tambahaksi(){
		$post = $this->input->post();
		$this->id_roti = $post['id_roti'];
		$this->nama_roti = $post['nama_roti'];
		$this->id_kategori = $post['kategori'];
		$this->harga_persatuan = $post['harga'];
		$this->stok = $post['stok'];
		$this->foto = $this->uploadGambar();
		$this->db->insert('roti',$this);
	}

	private function hapusGambar($id){
   	 	$roti =  $this->db->get_where('roti',['id_roti'=>$id])->row();
	   	 	if ($roti->foto != "default.jpg") {
		    $filename = explode(".", $roti->foto)[0];
			return array_map('unlink', glob(FCPATH."assets/img/roti/$filename.*"));
    	}
	}

	public function editaksi(){
		$post = $this->input->post();
		$this->id_roti = $post['id_roti'];
		$this->nama_roti = $post['nama_roti'];
		$this->id_kategori = $post['kategori'];
		$this->harga_persatuan = $post['harga'];
		$this->stok = $post['stok'];
		if(empty($_FILES['foto']['name'])){
			$this->foto = $post['foto-lama'];
		}
		else{
			$this->hapusGambar($this->id_roti);
			$this->foto = $this->uploadGambar();
		}
		$this->db->update('roti',$this, array('id_roti'=>$post['id_roti']));
	}

	public function hapusaksi($id){
		$this->hapusGambar($id);
		$this->db->delete('roti',array('id_roti'=>$id));
	}

	public function cariaksi(){
		$post = $this->input->post();
		$cari = $post['cari'];
		$this->db->select('*');
		$this->db->from('roti');
		$this->db->join('kategori','roti.id_kategori=kategori.id_kategori');
		$this->db->like('nama_roti',$cari);
		$ketemu = $this->db->get()->result_array();
		return $ketemu;
	}
}