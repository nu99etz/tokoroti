    <div class="container-fluid">
    <form action="<?php echo base_url("Utama/tambahroti")?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>ID Roti</label>
            <input type="text" class="form-control" id="id_roti" name="id_roti" placeholder="ID Roti">
        </div>
        <div class="form-group">
            <label>Nama Roti</label>
            <input type="text" class="form-control" id="nama_roti" name="nama_roti" placeholder="Nama Roti">
        </div>
        <div class="form-group">
            <label>Nama Roti</label>
            <select id="kategori" name="kategori" class="form-control">
                <option value="">Pilih</option>
                <?php foreach($kat as $kats){ ?>
                    <option value="<?php echo $kats['id_kategori'];?>"><?php echo $kats['nama_kategori'];?></option>
                <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <label>Harga</label>
            <input type="number" class="form-control" id="harga" name="harga" placeholder="Harga">
        </div>
        <div class="form-group">
            <label>Stok</label>
            <input type="number" class="form-control" id="stok" name="stok" placeholder="Stok">
        </div>
        <div class="form-group">
            <label>Gambar Roti</label>
            <input type="file" class="form-control" id="foto" name="foto" placeholder="Gambar Roti">
        </div>
        <div class="form-group">
            <input type="submit" id="foto" name="submit" value="Tambah">
        </div>
    </form>   
    </div> 