<div id="view">
	<?php $this->load->view('admin/login.php'); ?>
</div>