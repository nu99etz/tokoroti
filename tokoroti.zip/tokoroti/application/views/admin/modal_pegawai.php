<div class="container-fluid">
  <br/><br/>
  <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
        <div class="input-group">
            <input type="text" id="cari" class="form-control" placeholder="Cari ..." aria-label="Search" aria-describedby="basic-addon2" name="cari">
            <div class="input-group-append">
                <button class="btn btn-success" id="bst" type="button">
                    <i class="fa fa-search"></i>
                </button>
            </div>
        </div>
    </form>    
  <button type="button" id="tambah" data-toggle="modal" data-target="#form-modal" class="btn btn-success pull-right">
        <span class="fa fa-plus"></span>  Tambah Data
        </button>
        <br/><br/>
<div id="view">
<?php $this->load->view('admin/viewpegawai',array('model'=>$pegawai)); ?>
</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="judul"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <br/>
      <div id="pesan-gagal" class="alert alert-danger">            
        </div>
      <div class="modal-body">
        <form>
        <div class="form-group">
            <label>NIP</label>
            <input type="text" class="form-control" id="nip" name="nip" placeholder="NIP">
        </div>
        <div class="form-group">
            <label>Nama Pegawai</label>
            <input type="text" class="form-control" id="nama_pegawai" name="nama_pegawai" placeholder="Nama Pegawai">
        </div>
        <div class="form-group">
            <label>Jenis Kelamin</label>
            <select id="jk" name="jk" class="form-control">
                <option value="">Pilih</option>
                <option value="L">Laki-laki</option>
                <option value="P">Perempuan</option>
            </select>
        </div>
       <div class="form-group">
            <label>Jabatan</label>
            <select id="jabatan" name="jabatan" class="form-control">
                <option value="">Pilih</option>
                <?php foreach($jabatan as $jb){ ?>
                  <option value="<?php echo $jb['id_jabatan'];?>"><?php echo $jb['nama_jabatan'];?></option> <?php } ?>
            </select>
        </div>
         <div class="form-group">
            <label>Password</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Password">
        </div>
        <div class="form-group">
            <label>Gambar Roti</label>
            <input type="hidden" class="form-control" id="foto-lama" name="foto-lama" placeholder="Gambar Roti">
            <input type="file" class="form-control" id="foto" name="foto" placeholder="Gambar Roti">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" id="simpan" class="btn btn-primary">Tambah</button>
        <button type="button" id="ubah-ck" class="btn btn-primary">Ubah</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="form-modal-hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="judul-hapus"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h5>Apakah Anda Yakin Menghapus Data Ini ???...</h5>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
        <button type="button" id="hps" class="btn btn-danger">Ya</button>
      </div>
    </div>
  </div>
</div>
</div>    