<div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Toko Roti Barokah </div>
      <div class="list-group list-group-flush">
        <a href="<?php echo base_url("Utama/");?>" id="dashboard" class="list-group-item list-group-item-action bg-light"><i class = "fa fa-dashboard"></i>  Dashboard</a>
        <a href="<?php echo base_url("Utama/viewroti")?>" id="roti" class="list-group-item list-group-item-action bg-light"><i class = "fa fa-database"></i>  Data Roti</a>
        <?php if($this->session->userdata('jabatan')!='Kasir'&&$this->session->userdata('jabatan')!='Pelayan'){ ?>
          <a href="<?php echo base_url("Utama/viewpegawai");?>" id="pegawai" class="list-group-item list-group-item-action bg-light"><i class = "fa fa-user"></i>  Data Pegawai</a>
        <?php } ?>
        <a href="<?php echo base_url("Utama/viewpesanan");?>" class="list-group-item list-group-item-action bg-light"><i class = "fa fa-envelope"></i>  Data Pesanan</a>
        <a href="<?php echo base_url("Utama/viewtransaksi");?>" class="list-group-item list-group-item-action bg-light"><i class = "fa fa-credit-card"></i>  Data Transaksi</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-light" id="menu-toggle"><i class = "fa fa-bars"></i></button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php echo $this->session->userdata('user');?>
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#"><?php echo $this->session->userdata('jabatan');?></a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="<?php echo base_url("Auth/logout");?>"><i class = "fa fa-sign-out"></i> Keluar</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>