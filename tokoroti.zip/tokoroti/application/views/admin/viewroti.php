<div id="pesan-sukses" class="alert alert-success"></div>
    <br/>
       <table class="table table-hover">
            <thead>
                <tr>
                  <th scope="col">No</th>
                  <th scope="col">Foto</th>
                  <th scope="col">ID Roti</th>
                  <th scope="col">Nama Roti</th>
                  <th scope="col">Kategori</th>
                  <th scope="col">Harga</th>
                  <th scope="col">Stok</th>
                  <?php if($this->session->userdata('jabatan')!='Kasir'&&$this->session->userdata('jabatan')!='Pelayan'){ ?>
                  <th scope="col">Aksi</th> <?php } ?>
                </tr>
            </thead>
<?php $no=1; foreach($roti as $rotis){ ?>
    <tbody>
            <tr>
              <th scope="row"><?php echo $no++;?></th>
              <td><img src = "<?php echo base_url()?>assets/img/roti/<?php echo $rotis['foto'];?>" width=200 height=200></td>
              <td><?php echo $rotis['id_roti'];?></td>
              <td><?php echo $rotis['nama_roti'];?></td>
              <td><?php echo $rotis['nama_kategori'];?></td>
              <td><?php echo $rotis['harga_persatuan'];?></td>
              <td><?php echo $rotis['stok'];?></td>
              <?php if($this->session->userdata('jabatan')!='Kasir'&&$this->session->userdata('jabatan')!='Pelayan'){ ?>
              <td><a href="javascript:void();" data-id="<?php echo $rotis['id_roti']; ?>" data-toggle="modal" data-target="#form-modal" class="btn btn-warning ubah"><span class="fa fa-pencil"></span></a>
                <input type="hidden" class="id_roti-value" value="<?php echo $rotis['id_roti'];?>">
                <input type="hidden" class="nama_roti-value" value="<?php echo $rotis['nama_roti'];?>">
                <input type="hidden" class="kategori-value" value="<?php echo $rotis['id_kategori'];?>">
                <input type="hidden" class="harga-value" value="<?php echo $rotis['harga_persatuan'];?>">
                <input type="hidden" class="stok-value" value="<?php echo $rotis['stok'];?>">
                <input type="hidden" class="foto-value" value="<?php echo $rotis['foto'];?>">
                <a href="javascript:void();" data-id="<?php echo $rotis['id_roti']; ?>" data-toggle="modal" data-target="#form-modal-hapus" class="btn btn-danger hapus"><span class="fa fa-trash"></span></a> <?php } ?>
            </tr>
<?php } ?>
    </tbody>
        </table>            
      </div>
    </div>
  </div>