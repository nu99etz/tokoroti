<div class="container-fluid">
  <br/><br/>
  <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
        <div class="input-group">
            <input type="text" id="cari" class="form-control" placeholder="Cari ..." aria-label="Search" aria-describedby="basic-addon2" name="cari">
            <div class="input-group-append">
                <button class="btn btn-success" id="bst" type="button">
                    <i class="fa fa-search"></i>
                </button>
            </div>
        </div>
    </form>     

  <?php if($this->session->userdata('jabatan')!='Kasir'&&$this->session->userdata('jabatan')!='Pelayan'){ ?>
  <button type="button" id="tambah" data-toggle="modal" data-target="#form-modal" class="btn btn-success pull-right">
        <span class="fa fa-plus"></span>  Tambah Data
        </button>
        <br/><br/>
  <?php } ?> 
<div id="view">
<?php $this->load->view('admin/viewroti',array('model'=>$roti)); ?>
</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="judul"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <br/>
      <div id="pesan-gagal" class="alert alert-danger">            
        </div>
      <div class="modal-body">
        <form>
        <div class="form-group">
            <label>ID Roti</label>
            <input type="text" class="form-control" id="id_roti" name="id_roti" placeholder="ID Roti">
        </div>
        <div class="form-group">
            <label>Nama Roti</label>
            <input type="text" class="form-control" id="nama_roti" name="nama_roti" placeholder="Nama Roti">
        </div>
        <div class="form-group">
            <label>Nama Roti</label>
            <select id="kategori" name="kategori" class="form-control">
                <option value="">Pilih</option>
                <?php foreach($kat as $kats){ ?>
                    <option value="<?php echo $kats['id_kategori'];?>"><?php echo $kats['nama_kategori'];?></option>
                <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <label>Harga</label>
            <input type="number" class="form-control" id="harga" name="harga" placeholder="Harga">
        </div>
        <div class="form-group">
            <label>Stok</label>
            <input type="number" class="form-control" id="stok" name="stok" placeholder="Stok">
        </div>
        <div class="form-group">
            <label>Gambar Roti</label>
            <input type="hidden" class="form-control" id="foto-lama" name="foto-lama" placeholder="Gambar Roti">
            <input type="file" class="form-control" id="foto" name="foto" placeholder="Gambar Roti">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" id="simpan" class="btn btn-primary">Tambah</button>
        <button type="button" id="ubah-ck" class="btn btn-primary">Ubah</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="form-modal-hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="judul-hapus"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h5>Apakah Anda Yakin Menghapus Data Ini ???...</h5>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
        <button type="button" id="hps" class="btn btn-danger">Ya</button>
      </div>
    </div>
  </div>
</div>
</div>    