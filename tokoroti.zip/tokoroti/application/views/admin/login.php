<nav class="navbar navbar-expand-lg navbar-light navbar-laravel">
    <div class="container">
        <a class="navbar-brand" href="<?php echo base_url("Utama/")?>">Toko Roti Barokah</a>
    </div>
</nav>

<div id="pesan-sukses" class="alert alert-success"></div>
<div id="pesan-gagal" class="alert alert-danger"></div>

<main class="login-form">
    <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Login</div>
                    <div class="card-body">
                        <form>
                            <div class="form-group row">
                                <label for="email_address" class="col-md-4 col-form-label text-md-right">NIP</label>
                                <div class="col-md-6">
                                    <input type="text" id="username" class="form-control" name="username">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password" class="col-md-4 col-form-label text-md-right">Password</label>
                                <div class="col-md-6">
                                    <input type="password" id="password" class="form-control" name="password">
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-6 offset-md-4">
                                </div>
                            </div>

                            <div class="col-md-6 offset-md-4" id="login">
                                <button type="button" id="log" class="btn btn-success"><i class="fa fa-sign-in"></i> Masuk</button>
                                <a href="#" class="btn btn-link">
                                    Forgot Your Password?
                                </a>
                            </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>

<div class="modal fade" id="form-modal-hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="judul-hapus"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="judul2">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
        <button type="button" id="hps" class="btn btn-danger">Ya</button>
      </div>
    </div>
  </div>
</div>
</div>    

</main>