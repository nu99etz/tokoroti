<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title><?php echo $judul;?></title>

  <!-- Bootstrap core CSS -->
  <link href="<?php echo base_url()?>assets/admin/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/font-awesome-4.7.0/css/font-awesome.min.css">

  <!-- Custom styles for this template -->
  <link href="<?php echo base_url()?>assets/admin/css/simple-sidebar.css" rel="stylesheet">
  <script> var base_url = '<?= base_url()?>'</script> 

</head>

<body>