<div id="pesan-sukses" class="alert alert-success"></div>
    <br/>
       <table class="table table-hover">
            <thead>
                <tr>
                  <th scope="col">No</th>
                  <th scope="col">Foto</th>
                  <th scope="col">NIP</th>
                  <th scope="col">Nama Pegawai</th>
                  <th scope="col">Jenis Kelamin</th>
                  <th scope="col">Jabatan</th>
                  <th scope="col">Aksi</th>
                </tr>
            </thead>
<?php $no=1; foreach($pegawai as $pegawais){ ?>
    <tbody>
            <tr>
              <th scope="row"><?php echo $no++;?></th>
              <td><img src = "<?php echo base_url()?>assets/img/pegawai/<?php echo $pegawais['foto'];?>" width=200 height=200></td>
              <td><?php echo $pegawais['nip'];?></td>
              <td><?php echo $pegawais['nama_pegawai'];?></td>
              <td><?php if($pegawais['jk']=="L"){
                echo "Laki-laki";
              } else{
                 echo "Perempuan"; } ?></td>
              <td><?php echo $pegawais['nama_jabatan'];?></td>
              <td><a href="javascript:void();" data-id="<?php echo $pegawais['nip']; ?>" data-toggle="modal" data-target="#form-modal" class="btn btn-warning ubah"><span class="fa fa-pencil"></span></a>
                <input type="hidden" class="nip-value" value="<?php echo $pegawais['nip'];?>">
                <input type="hidden" class="nama_pegawai-value" value="<?php echo $pegawais['nama_pegawai'];?>">
                <input type="hidden" class="jk-value" value="<?php echo $pegawais['jk'];?>">
                <input type="hidden" class="jabatan-value" value="<?php echo $pegawais['jabatan'];?>">
                <input type="hidden" class="password-value" value="<?php echo $pegawais['password'];?>">
                <input type="hidden" class="foto-value" value="<?php echo $pegawais['foto'];?>">
                <a href="javascript:void();" data-id="<?php echo $pegawais['nip']; ?>" data-toggle="modal" data-target="#form-modal-hapus" class="btn btn-danger hapus"><span class="fa fa-trash"></span></a>
            </tr>
<?php } ?>
    </tbody>
        </table>            
      </div>
    </div>
  </div>