$(document).ready(function(){
	$('#pesan-sukses,#pesan-gagal').hide()
	$('#log').click(function(){
		var cek1 = $('#username').val();
        var cek2 = $('#password').val();
        if(cek1==""||cek2==""){
        	 $('#pesan-gagal').html("Data Harus Diisi").fadeIn().delay(10000).fadeOut()
        }
        else{
        	 $.ajax({
                type : "POST",
                url  : base_url + "Auth/loginaksi",
                dataType : "JSON",
                data : {username: cek1,password: cek2},
                success: function(data){
                	if(data.status=='sukses'){
                		$('#form-modal-hapus').modal('toggle')
                		$('#judul2').html(data.pesan)
                		/*setTimeout(function(){
        					$("#form-modal-hapus").modal('hide');
    					}, 10000);*/
                		window.location.assign("index")
                	}else{
                		$('#pesan-gagal').html(data.pesan).fadeIn().delay(10000).fadeOut()
                	}
                }/*,
                error: function (xhr, ajaxOptions, thrownError) { // Ketika terjadi error
       			 	alert(xhr.responseText) // munculkan alert
      			}*/
            });
            return false;
        }
		/*	*/
	})
})