var id=0;
$(document).ready(function(){
	$('#pesan-sukses,#pesan-gagal').hide()
$('#tambah').click(function(){
	$('#simpan').show()
	$('#ubah-ck').hide()
    $('#foto-lama').hide()
	$('#judul').html('Form Tambah')
})
	$('#simpan').on('click',function(){
        var isi = new FormData($('#form-modal')[0]);
        isi.append('id_roti',$('#id_roti').val());
        isi.append('nama_roti',$('#nama_roti').val());
        isi.append('kategori',$('#kategori').val());
        isi.append('harga',$('#harga').val());
        isi.append('stok',$('#stok').val());
        isi.append('foto',$('input[type=file]')[0].files[0]);
            $.ajax({
                type : "POST",
                url  : base_url + "Utama/tambahroti",
                dataType : "JSON",
                data : isi,
                cache: false,
                processData: false,
                contentType: false,
                success: function(data){
                	if(data.status=='sukses'){
                		$('#view').html(data.html)
                    	$('#form-modal').modal('hide')
                    	$('#pesan-sukses').html(data.pesan).fadeIn().delay(10000).fadeOut()
                	}else{
                		$('#pesan-gagal').html(data.pesan).fadeIn().delay(10000).fadeOut()
                	}
                }
            });
            return false;
        });
$('#view').on('click','.ubah',function(){
    id = $(this).data('id')
    $('#simpan').hide()
    $('#ubah-ck').show()
    $('#foto-lama').show()
    var cari = $(this).closest('tr')
    var id_roti = cari.find('.id_roti-value').val()
    var nama_roti = cari.find('.nama_roti-value').val()
    var kategori = cari.find('.kategori-value').val()
    var harga = cari.find('.harga-value').val()
    var stok = cari.find('.stok-value').val()
    var jabatan = cari.find('.jabatan-value').val()
    var foto = cari.find('.foto-value').val()
    $('#id_roti').val(id_roti)
    $('#nama_roti').val(nama_roti)
    $('#kategori').val(kategori)
    $('#harga').val(harga)
    $('#stok').val(stok)
    $('#jabatan').val(jabatan)
    $('#foto-lama').val(foto)
    $('#judul').html('Ubah Data '+nama_roti)
})
    $('#ubah-ck').on('click',function(){
        var up = new FormData($('#form-modal')[0]);
        up.append('id_roti',$('#id_roti').val());
        up.append('nama_roti',$('#nama_roti').val());
        up.append('kategori',$('#kategori').val());
        up.append('harga',$('#harga').val());
        up.append('stok',$('#stok').val());
        up.append('foto-lama',$('#foto-lama').val())
        up.append('foto',$('input[type=file]')[0].files[0]);
            $.ajax({
                type : "POST",
                url  : base_url + "Utama/ubahroti",
                dataType : "JSON",
                data : up,
                cache: false,
                processData: false,
                contentType: false,
                success: function(data){
                    if(data.status=='sukses'){
                        $('#view').html(data.html)
                        $('#form-modal').modal('hide')
                        $('#pesan-sukses').html(data.pesan).fadeIn().delay(10000).fadeOut()
                    }else{
                        $('#pesan-gagal').html(data.pesan).fadeIn().delay(10000).fadeOut()
                    }
                }
            });
            return false;
        });
$('#view').on('click','.hapus',function(){
    id = $(this).data('id')
    var cari = $(this).closest('tr')
    var nama_roti = cari.find('.nama_roti-value').val()
    $('#judul-hapus').html('Hapus '+nama_roti)
})
    $('#hps').on('click',function(){
        $.ajax({
            type : "GET",
            url  : base_url + "Utama/hapusroti/" +id,
            dataType : "JSON",
            success: function(data){
                $('#view').html(data.html)
                $('#form-modal-hapus').modal('hide')
                $('#pesan-sukses').html(data.pesan).fadeIn().delay(10000).fadeOut()
            }
        });
        return false;
    });
    $('#bst').on('click',function(){
        var cek1 = $('#cari').val();
        $.ajax({
            type : "POST",
            url  : base_url + "Utama/cariroti",
            dataType : "JSON",
            data : {cari: cek1},
            success: function(data){
                $('#view').html(data.html)
                $('#pesan-sukses').hide()
            },
            error: function (xhr, ajaxOptions, thrownError) { // Ketika terjadi error
                alert(xhr.responseText) // munculkan alert
            }    
        })
    })

    $('#form-modal').on('hidden.bs.modal', function (e){
    $('#form-modal input, #form-modal select, #form-modal textarea').val('')
  })        
})