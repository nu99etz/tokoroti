var id=0;
$(document).ready(function(){
	$('#pesan-sukses,#pesan-gagal').hide()
$('#tambah').click(function(){
	$('#simpan').show()
	$('#ubah-ck').hide()
    $('#foto-lama').hide()
	$('#judul').html('Form Tambah')
})
	$('#simpan').on('click',function(){
        var isi = new FormData($('#form-modal')[0]);
        isi.append('nip',$('#nip').val());
        isi.append('nama_pegawai',$('#nama_pegawai').val());
        isi.append('jabatan',$('#jabatan').val());
        isi.append('jk',$('#jk').val());
        isi.append('password',$('#password').val());
        isi.append('foto',$('input[type=file]')[0].files[0]);
            $.ajax({
                type : "POST",
                url  : base_url + "Utama/tambahpegawai",
                dataType : "JSON",
                data : isi,
                cache: false,
                processData: false,
                contentType: false,
                success: function(data){
                	if(data.status=='sukses'){
                		$('#view').html(data.html)
                    	$('#form-modal').modal('hide')
                    	$('#pesan-sukses').html(data.pesan).fadeIn().delay(10000).fadeOut()
                	}else{
                		$('#pesan-gagal').html(data.pesan).fadeIn().delay(10000).fadeOut()
                	}
                }
            });
            return false;
        });
 $('#view').on('click','.ubah',function(){
    id = $(this).data('id')
    $('#simpan').hide()
    $('#ubah-ck').show()
    $('#foto-lama').show()
    var cari = $(this).closest('tr')
    var nip = cari.find('.nip-value').val()
    var nama_pegawai = cari.find('.nama_pegawai-value').val()
    var jk = cari.find('.jk-value').val()
    var jabatan = cari.find('.jabatan-value').val()
    var password = cari.find('.password-value').val()
    var foto = cari.find('.foto-value').val()
    $('#nip').val(nip)
    $('#nama_pegawai').val(nama_pegawai)
    $('#jk').val(jk)
    $('#jabatan').val(jabatan)
    $('#password').val(password)
    $('#foto-lama').val(foto)
    $('#judul').html('Ubah Data '+nama_pegawai)
})  
    $('#ubah-ck').on('click',function(){
        var up = new FormData($('#form-modal')[0]);
        up.append('nip',$('#nip').val());
        up.append('nama_pegawai',$('#nama_pegawai').val());
        up.append('jabatan',$('#jabatan').val());
        up.append('jk',$('#jk').val());
        up.append('password',$('#password').val());
        up.append('foto-lama',$('#foto-lama').val())
        up.append('foto',$('input[type=file]')[0].files[0]);
            $.ajax({
                type : "POST",
                url  : base_url + "Utama/ubahpegawai",
                dataType : "JSON",
                data : up,
                cache: false,
                processData: false,
                contentType: false,
                success: function(data){
                    if(data.status=='sukses'){
                        $('#view').html(data.html)
                        $('#form-modal').modal('hide')
                        $('#pesan-sukses').html(data.pesan).fadeIn().delay(10000).fadeOut()
                    }else{
                        $('#pesan-gagal').html(data.pesan).fadeIn().delay(10000).fadeOut()
                    }
                }
            });
            return false;
        }); 
$('#view').on('click','.hapus',function(){
    id = $(this).data('id')
    var cari = $(this).closest('tr')
    var nama_pegawai = cari.find('.nama_pegawai-value').val()
    $('#judul-hapus').html('Hapus '+nama_pegawai)
})
    $('#hps').on('click',function(){
        $.ajax({
            type : "GET",
            url  : base_url + "Utama/hapuspegawai/" +id,
            dataType : "JSON",
            success: function(data){
                $('#view').html(data.html)
                $('#form-modal-hapus').modal('hide')
                $('#pesan-sukses').html(data.pesan).fadeIn().delay(10000).fadeOut()
            }
        });
        return false;
    });	
    $('#bst').on('click',function(){
        var cek1 = $('#cari').val();
        $.ajax({
            type : "POST",
            url  : base_url + "Utama/caripegawai",
            dataType : "JSON",
            data : {cari: cek1},
            success: function(data){
                $('#view').html(data.html)
                $('#pesan-sukses').hide()
            },
            error: function (xhr, ajaxOptions, thrownError) { // Ketika terjadi error
                alert(xhr.responseText) // munculkan alert
            }    
        })
    })
	$('#form-modal').on('hidden.bs.modal', function (e){
    $('#form-modal input, #form-modal select, #form-modal textarea').val('')
  })  
})